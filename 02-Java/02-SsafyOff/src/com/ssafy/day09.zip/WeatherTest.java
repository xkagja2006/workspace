package com.ssafy.day09;

public class WeatherTest {
	public static void main(String[] args) throws Throwable {
		new WeatherService();
	}
}